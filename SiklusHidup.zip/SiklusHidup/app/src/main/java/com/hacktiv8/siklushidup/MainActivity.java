package com.hacktiv8.siklushidup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "SIKLUS HIDUP ACT";
    private EditText komentarText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        System.out.println(TAG + "On Create");

        komentarText = findViewById(R.id.komentar);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(this, "On start", Toast.LENGTH_SHORT).show();
        System.out.println(TAG + "On start");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(this, "On stop", Toast.LENGTH_SHORT).show();
        System.out.println(TAG + "On stop");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(this, "On pause", Toast.LENGTH_SHORT).show();
        System.out.println(TAG + "On pause");

        String komentar = komentarText.getText().toString();
        SharedPreferences.Editor editor = getSharedPreferences("siklus_hidup", Context.MODE_PRIVATE).edit();
        editor.putString("komentar", komentar);
        editor.apply();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this, "On resume", Toast.LENGTH_SHORT).show();
        System.out.println(TAG + "On resume");

        SharedPreferences sharedPreferences = getSharedPreferences("siklus_hidup", Context.MODE_PRIVATE);
        String dataTersimpan = sharedPreferences.getString("komentar", "");

        komentarText.setText(dataTersimpan);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "On destroy", Toast.LENGTH_SHORT).show();
        System.out.println(TAG + "On destroy");
    }
}
